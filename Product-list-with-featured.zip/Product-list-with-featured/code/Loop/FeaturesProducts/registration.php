<?php
/**
 *
 * @category Customization
 * @license  http://opensource.org/licenses/gpl-3.0.html GNU General Public License
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Loop_FeaturesProducts',
    __DIR__
);
