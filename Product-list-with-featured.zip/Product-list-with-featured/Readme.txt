Here is the point for challenge

1. Place design folder into fresh magento setup. I have use enterprise ver. 2.4.6.

2. I have attached DB with the name of loop_challenge_08_03.sql Please import the DB.

3. as per the point i have create 1 website with 1 store and 2 store view.

4. After setup run command as needed. Upgrade/compile/Deploy/Flush.

5. After the command verify the product on home page.

6. I've attached Screen shot for design. Path (Product_List)