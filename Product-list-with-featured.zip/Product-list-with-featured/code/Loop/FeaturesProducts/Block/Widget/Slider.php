<?php

namespace Loop\FeaturesProducts\Block\Widget;

use Magento\Framework\View\Element\Template;
use Magento\Widget\Block\BlockInterface;
use \Magento\Framework\View\Element\Template\Context;

class Slider extends Template implements BlockInterface
{
    protected $_template;

    protected $_collectionFactory = null;

    public function __construct(
        Context $context,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $collectionFactory,
        array $data = [],
    ) {
        $this->_collectionFactory  = $collectionFactory;
        parent::__construct($context,$data);
    }

    public function getCollection()
    {
        /** @var ViewCollection $viewCollection */
        $viewCollection = $this->_collectionFactory ->create();
        $viewCollection->addFieldToSelect(['*'])->addFieldtoFilter('featured',['eq'=>1]);
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/testlog.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);
        $logger->info(print_r($viewCollection->toArray(),true));
        return $viewCollection->toArray();
    }


    
    protected function _toHtml()
    {
        if ($this->getData('layout') == 'grid') {
            $this->setTemplate('grid.phtml');
        }
        return parent::_toHtml();
    }
    
}
?>